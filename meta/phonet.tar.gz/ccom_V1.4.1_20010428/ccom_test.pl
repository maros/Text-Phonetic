#! /opt/perl5/bin/perl

#
# ccom_test.pl
# ------------
#
# PERL-skript to check if installation of ccom::phonet() was correct.
#
# Copyright (c):
# 2000:  Michael Maretzke, M�nchen, Germany
#
# This program is subject to the GNU Library General Public License (LGPL)
# as published by the Free Software Foundation; either version 2 of the
# License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# You should have received a copy of the GNU Library General Public License
# along with this program; if not, write to the
# Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#
# Actually, the LGPL is __less__ restrictive than the better known GNU General
# Public License (GPL). See the GNU Library General Public License or the file
# COPYING.LIB for more details and for a DISCLAIMER OF ALL WARRANTIES.
#
# There is one important restriction: If you modify this program in any way
# (e.g. add or change phonetic rules or modify the underlying logic or
# translate this program into another programming language), you must also
# release the changes under the terms of the LGPL.
# That means you have to give out the source code to your changes,
# and a very good way to do so is mailing them to the address given below.
# I think this is the best way to promote further development and use
# of this software.
#
# If you have any remarks, feel free to e-mail to:
#     michael@maretzke.de
#


use ccom;

print "\n";
print "About to check installation of library \"ccom\" Version 1.3\n\n";

print "1) ccom::phonet(\"Festplatte\") --> ";
print ccom::phonet ("Festplatte");
print "\n";

print "2) ccom::phonet(\"Loch\") --> ";
print ccom::phonet ("Loch");
print "\n";

print "3) ccom::phonetRulesetOne(\"Loch\") --> ";
print ccom::phonetRulesetOne ("Loch");
print "\n";

print "4) ccom::phonetRulesetTwo(\"Loch\") --> ";
print ccom::phonetRulesetTwo ("Loch");
print "\n";



print "\n";

print "Installation was successfull if screen looks like this:\n\n";
print "1) ccom::phonet(\"Festplatte\") --> FEZTBLATE\n";
print "2) ccom::phonet(\"Loch\") --> LUK\n";
print "3) ccom::phonetRulesetOne(\"Loch\") --> LOCH\n";
print "4) ccom::phonetRulesetTwo(\"Loch\") --> LUK\n";
print "\n\n";

