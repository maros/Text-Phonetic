#
# README.txt
# ----------
#
# PERL-Library to connect Joerg Michael's program for phonetic string conversion
# with the PERL programming language.
#
# Copyright (c):
# 2000,2001:  Michael Maretzke, Muenchen, Germany
#
# This program is subject to the GNU Library General Public License (LGPL)
# as published by the Free Software Foundation; either version 2 of the
# License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# You should have received a copy of the GNU Library General Public License
# along with this program; if not, write to the
# Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#
# Actually, the LGPL is __less__ restrictive than the better known GNU General
# Public License (GPL). See the GNU Library General Public License or the file
# COPYING.LIB for more details and for a DISCLAIMER OF ALL WARRANTIES.
#
# There is one important restriction: If you modify this program in any way
# (e.g. add or change phonetic rules or modify the underlying logic or
# translate this program into another programming language), you must also
# release the changes under the terms of the LGPL.
# That means you have to give out the source code to your changes,
# and a very good way to do so is mailing them to the address given below.
# I think this is the best way to promote further development and use
# of this software.
#
# If you have any remarks, feel free to e-mail to:
#     michael@maretzke.de
#
# Version ccom 1.4.1 contains phonet ruleset Version 1.3.1 from 2001-04-28
#

Version 1.4.1 - Date 2001-04-28
----------------------------------------------------------------------------------------------

README file for installation of perl package "ccom"

----------------------------------------------------------------------------------------------
installation requirements:

	* SUN Solaris Operating System
	* correctly installed PERL-Version (we use version 5.005_03 built for sun4-solaris)
	* standard C-compiler

----------------------------------------------------------------------------------------------
installation:

step 1:	untar file ccom_V1.3_20001006.tar.gz into a directory
	-> source files will be decompressed

step 2:	change into directory and enter "perl Makefile.PL" 
	-> makefiles for library compilation are generated
	[ don't worry if any warning caused by missing files occur ]
		
step 3: enter "make"
	-> perl library and shared library for "phonet" are build
	
step 4: enter "make install" [ therefor you should have "root" access rights ]
	-> the perl library will be installed into the correct public directory 
	   of your perl installation

step 5: change into a directory of your choice different from your 
	installation directory and type "perl /path-to-install/../ccom_test.pl"
	-> the installation of ccom-library will be checked
